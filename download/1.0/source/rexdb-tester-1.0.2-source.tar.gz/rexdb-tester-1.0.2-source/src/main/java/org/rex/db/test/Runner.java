package org.rex.db.test;

public interface Runner {

	public void run() throws Exception;
}
