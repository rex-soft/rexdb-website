# 目录结构 #

您下载的是编译好的Rexdb框架，目录结构如下：

- /lib：编译好的Rexdb，以及可选用的第三方Jar包
- /conf：Rexdb配置文件示例
- /doc：文档
- LICENSE.txt：用户协议
- README.txt：使用指引

# 编译环境 #

Rexdb编译于JDK 5.0版本；/lib中的jar包均可运行于JDK 5.0及以上版本。

# 如何使用 #

请浏览/doc目录中的文档，以及官方网站。

# Rexdb官方网站 #

http://db.rex-soft.org/